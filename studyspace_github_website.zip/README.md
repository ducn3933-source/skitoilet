# StudySpace — giao diện web học tập

## Chạy thử
Mở `index.html` bằng trình duyệt.

## Đưa lên GitHub Pages
1. Tạo repository công khai trên GitHub.
2. Tải `index.html` lên repository (đặt ở thư mục gốc).
3. Mở **Settings → Pages**.
4. Chọn **Deploy from a branch**, nhánh `main`, thư mục `/(root)`, rồi nhấn **Save**.
5. Chờ GitHub Pages triển khai và mở URL được cung cấp trong phần Pages.

Đây là bản demo giao diện tĩnh; các số liệu và nội dung là dữ liệu mẫu. Đăng nhập thật, đồng bộ dữ liệu và quản lý người dùng cần backend riêng.
